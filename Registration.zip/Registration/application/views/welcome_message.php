<!DOCTYPE html>
<html>
<head>
	<title>Register</title>
</head>
<body>
	<form role="form" action="" method="POST">
	<div class="container">
		<div class="form-group">
			<label>FirstName</label>
			<input type="text" name="firstname">
		</div>
		<div class="form-group">
			<label>LastName</label>
			<input type="text" name="lastname">
		</div>
		<div class="form-group">
			<label>Email Adress</label>
			<input type="text" name="email">
		</div>
		<div class="form-group">
			<label>Mobile No</label>
			<input type="text" name="firstname">
		</div>
		<div class="form-group">
			<input type="submit" name="submit">
		</div>
		
	</div>
</form>
</body>
</html>
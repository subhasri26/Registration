<div id="footer_bottom" class="footer-bottom">
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="copyright">2019-2020 © <a href="#">FormGet.com</a> All rights reserved.</div>
</div>
</div>
</div>
</div>
</body>
</html>